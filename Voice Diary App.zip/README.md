
  # Voice Diary App

  This is a code bundle for Voice Diary App. The original project is available at https://www.figma.com/design/SQQUOtDYtZ3znpYWtH1OVJ/Voice-Diary-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  